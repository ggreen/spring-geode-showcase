Dockers in this folder are built, and uploaded to the redisfab dockerhub store.
