Examples
########

.. toctree::
   :maxdepth: 3
   :glob:

   examples/connection_examples
   examples/ssl_connection_examples
   examples/asyncio_examples
   examples/search_json_examples
   examples/set_and_get_examples
   examples/search_vector_similarity_examples