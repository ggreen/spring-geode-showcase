

Exceptions
##########

.. automodule:: redis.exceptions
    :members: