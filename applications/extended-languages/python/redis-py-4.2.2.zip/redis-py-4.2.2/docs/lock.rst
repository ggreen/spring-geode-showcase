Lock
#########

.. automodule:: redis.lock
    :members: 