Backoff
#############

.. automodule:: redis.backoff
    :members: 